import { useState, useEffect, useCallback } from 'react'
import { t } from '../utils/theme'
import { useSettings } from '../context/SettingsContext'

export default function MiniTasbih({ target = 33, count = 0, onCountChange }) {
    const { theme } = useSettings()
    const [isVisible, setIsVisible] = useState(false)

    // Show with a slight delay for entry animation
    useEffect(() => {
        const timer = setTimeout(() => setIsVisible(true), 300)
        return () => clearTimeout(timer)
    }, [])

    const handleTap = useCallback((e) => {
        e.stopPropagation()
        if (count < target || target === 0) {
            if (navigator.vibrate) navigator.vibrate(15) // Match main Tasbih haptic feedback
            onCountChange(count + 1)
            
            // Sync with global total dhikr count just like the main Tasbih page
            try {
                const currentTotal = parseInt(localStorage.getItem('dhikr-total') || '0')
                localStorage.setItem('dhikr-total', String(currentTotal + 1))
            } catch (err) {}
        } else {
            if (navigator.vibrate) navigator.vibrate([20, 30, 20])
        }
    }, [count, target, onCountChange])

    const progress = target > 0 ? Math.min((count / target) * 100, 100) : 0
    const isLight = theme === 'light'
    const isDark = theme === 'dark'

    const ringColor = isLight ? '#FACC15' : t(theme, 'accent')
    const trackColor = isLight ? '#F8FAFC' : (isDark ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.03)')

    return (
        <div
            className={`fixed bottom-28 right-6 z-[110] flex flex-col items-center gap-4 transition-all duration-700 transform ${isVisible ? 'translate-y-0 opacity-100' : 'translate-y-12 opacity-0'}`}
        >
            {/* Main Tasbih Circle */}
            <button
                onClick={handleTap}
                className="relative w-20 h-20 rounded-[2.5rem] flex items-center justify-center transition-all active:scale-[0.85] hover:scale-105 shadow-2xl group overflow-visible select-none outline-none focus:outline-none focus-visible:outline-none focus:ring-0"
                style={{
                    WebkitTapHighlightColor: 'transparent',
                    background: isDark ? 'rgba(30, 36, 45, 0.85)' : 'rgba(236, 230, 208, 0.95)',
                    backdropFilter: 'blur(20px)',
                    border: `1.5px solid ${t(theme, 'border')}`,
                    boxShadow: isDark
                        ? '0 25px 60px rgba(0,0,0,0.6), inset 0 1px 1px rgba(255,255,255,0.05)'
                        : '0 20px 45px rgba(138, 109, 27, 0.12), inset 0 1px 1px rgba(255,255,255,1)'
                }}
            >
                {/* Progress Ring */}
                <svg className="absolute -inset-2 w-[calc(100%+16px)] h-[calc(100%+16px)] transform -rotate-90 pointer-events-none">
                    <circle
                        cx="50%" cy="50%" r="38%"
                        fill="none"
                        stroke={trackColor}
                        strokeWidth="4.5"
                    />
                    <circle
                        cx="50%" cy="50%" r="38%"
                        fill="none"
                        stroke={ringColor}
                        strokeWidth="5.5"
                        strokeLinecap="round"
                        pathLength="100"
                        strokeDasharray="100"
                        strokeDashoffset={100 - progress}
                        className="transition-all duration-500 cubic-bezier(0.19, 1, 0.22, 1)"
                        style={{ 
                            filter: `drop-shadow(0 0 8px ${isLight ? '#EAB30855' : t(theme, 'accent')}55)`,
                            opacity: count === 0 ? 0.05 : 1
                        }}
                    />
                </svg>

                <div className="relative flex flex-col items-center leading-none mt-1 pointer-events-none">
                    <span 
                        className="text-[26px] font-black tabular-nums tracking-tighter" 
                        style={{ color: t(theme, 'text-primary') }}
                    >
                        {count}
                    </span>
                    <span 
                        className="text-[10px] font-black opacity-30 uppercase tracking-widest mt-1.5" 
                        style={{ color: t(theme, 'text-muted') }}
                    >
                        /{target || 100}
                    </span>
                </div>
            </button>
        </div>
    )
}
